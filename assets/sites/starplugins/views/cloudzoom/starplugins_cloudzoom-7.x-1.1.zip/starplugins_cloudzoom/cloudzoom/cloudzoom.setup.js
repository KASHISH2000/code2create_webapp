CloudZoom.quickStart();
