(c)2012 Star Plugins

WordPress plugin to integrate Cloud Zoom V2.0+

INSTALLATION INSTRUCTIONS

1. Download either a trial or full commercial version of Cloud Zoom V2.0 (or newer)

2. Extract the downloaded file, 'cloudzoom.zip'.
   You should end up with a folder called 'cloudzoom'

3. Download a copy of the Cloud Zoom WordPress module, 'cloudzoom-wordpress.zip'

4. Create a folder called 'cloudzoom-wordpress' in your '/wp-content/plugins' directory

5. Extract 'cloudzoom-wordpress.zip' into your 'cloudzoom-wordpress' folder

6. Copy the contents of your 'cloudzoom' folder, into the empty cloudzoom folder
   found inside '/wp-content/plugins/cloudzoom-wordpress'

7. Activate the module in the usual way