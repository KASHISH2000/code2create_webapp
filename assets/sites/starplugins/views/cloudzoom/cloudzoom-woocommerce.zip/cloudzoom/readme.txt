This folder is intentionally empty.

You should copy the contents of the downloaded cloudzoom.zip file into here.

It should contain files such as cloudzoom.js, cloudzoom.css etc.

You can delete the sample images folder if you don't want them.