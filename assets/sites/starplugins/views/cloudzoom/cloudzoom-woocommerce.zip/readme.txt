(c)2013 Star Plugins

WooCommerce/WordPress plugin to integrate Cloud Zoom V2.0+

INSTALLATION INSTRUCTIONS

1. Download either a trial or full commercial version of Cloud Zoom V2.0 (or newer)

2. Extract the downloaded file, 'cloudzoom.zip'.
   You should end up with a folder called 'cloudzoom'

3. Download a copy of the Cloud Zoom WooCommerce module, 'cloudzoom-woocommerce.zip'

4. Create a folder called 'cloudzoom-woocommerce' in your '/wp-content/plugins' directory

5. Extract 'cloudzoom-woocommerce.zip' into your 'cloudzoom-woocommerce' folder

6. Copy the contents of your 'cloudzoom' folder, into the empty cloudzoom folder
   found inside '/wp-content/plugins/cloudzoom-woocommerce'

7. Activate the module in the usual way