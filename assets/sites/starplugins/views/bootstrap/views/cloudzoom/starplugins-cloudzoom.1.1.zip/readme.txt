Star Plugins Cloud Zoom Open Cart Extension V1.1
================================================

This Open Cart extension enables Star Plugins Cloud Zoom functionality in your store.
It has been tested on Open Cart 1.5.6.4 with standard template. Other templates may require some modification to the starplugins-cloudzoom.xml file.

Compared to the old Professor Cloud plugin, it offers many new facilities suitable for modern, touch-enabled devices and responsive websites. It also works with the ColorBox pop-up window on click.

It comes bundled with an unlicensed trial version of Star Plugins Cloud Zoom.

You will need to obtain an appropriate license for commercial use.

If you purchase a license, you will need to copy the cloudzoom.js file to the following location: catalog\view\javascript\jquery\starplugins-cloudzoom

How to install
==============

1) Copy the contents of the "upload" folder to your store root directory.

Cloud Zoom should automatically work on your product pages.

Modifying Cloud Zoom Properties
===============================

Cloud Zoom properties can be modified inside the following file:
\vqmod\xml\starplugins-cloudzoom.xml
You will need to find the data-cloudzoom attribute in the source and modify the properties there.

Further info here: www.starplugins.com
(C)2014 Star Plugins

